package classic.web.app;

import java.sql.*;
import java.util.*;

public class CustomerBean implements java.io.Serializable {

	private String user;
	private String password;

	public final String getUser() { return user; }
	public final void setUser(String value) { user = value; }

	public final String getPassword() { return password; }
	public final void setPassword(String value) { password = value; }

	public boolean authenticate() throws SQLException {
		try(var con = DB.connect()){
			var pstmt = con.prepareStatement("select count(username) from admin where username=? and password=?");
			pstmt.setString(1, user);
			pstmt.setString(2, password);
			var rs = pstmt.executeQuery();
			rs.next();
			int count = rs.getInt(1);
			rs.close();
			pstmt.close();
			if(count == 1)
				return true;
			user = password = null;
			return false;
		}
	}
	
	public List<OrderEntry> getOrders() throws SQLException {
		var orders = new ArrayList<OrderEntry>();
		try(var con = DB.connect()){
			var pstmt = con.prepareStatement("select no, name, branch, crank, year from student");
			var rs = pstmt.executeQuery();
			while(rs.next())
				orders.add(new OrderEntry(rs));
			rs.close();
			pstmt.close();
		}
		return orders;
	}


	public static class OrderEntry {
		
		private int stud_No;
		private String stud_Name;
		private String stud_Branch;
		private int stud_Rank;
		private int stud_Year;

		OrderEntry(ResultSet rs) throws SQLException {
			stud_No = rs.getInt("no");
			stud_Name = rs.getString("name");
			stud_Branch = rs.getString("branch");
			stud_Rank = rs.getInt("crank");
			stud_Year = rs.getInt("year");
		}

		public final int getStud_No() { return stud_No; }

		public final String getStud_Name() { return stud_Name; }

		public final String getStud_Branch() { return stud_Branch; }

		public final int getStud_Rank() { return stud_Rank; }

		public final int getStud_Year() { return stud_Year; }

	}
}

