package series;

public interface Taxable{
	
	 double getTax(); 

}
