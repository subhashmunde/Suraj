package series;

public  class SeqCreator{

	public static Sequence createLinear(int num, int step){
		Sequence ls = new LinearSequence(num, step);
		return ls;
	}

	public static Sequence createPower(int num, int factor){
		Sequence ps = new PowerSequence(num, factor);
		return ps;
	}
}	
