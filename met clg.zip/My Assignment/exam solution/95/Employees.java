class Employees{
   private int empid;
   private String name;
   private String designation;
   public static int count;
   public Employees(){
}
    public Employees (int empid,String name, String designation){
         this.empid=empid;
         this.name=name;
         this.designation=designation;
         count++;
   
   }
    public static int getempid(int empid){
         return empid;
   }

    public static String getname(String name){
         return name;
   }
    public static String getdesignation(String designation){
      return designation;
   }
   public String toString(){
       return empid+""+name+""+designation;
    }
 
      public static void main(String[]args){
    
      Employees emp1=new Employees(11 ,"omkar" ,"post1");

      Employees emp2=new Employees(12 ,"om" ,"post2");
      
      Employees emp3=new Employees(13 ,"omi" ,"post3");
      System.out.println("There are"+Employees.count+"objects in this class.");
      
      System.out.println (emp1);
     
      System.out.println (emp2);
       
      System.out.println (emp3);
   }
}
