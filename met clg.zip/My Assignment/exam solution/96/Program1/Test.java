import cal.*;
import java.util.*; 
//import java.util.Scanner;

class Test
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		
		System.out.println("Enter Day = ");
		int day=s.nextInt();

		System.out.println("Enter Month = ");
		int month=s.nextInt();

		System.out.println("Enter year = ");
		int year=s.nextInt();
		
		System.out.println("Enter Student Id = ");
		int id=s.nextInt();
		
		System.out.println("Enter Student Name = ");
		String name= s.nextLine();  

		System.out.println("Enter Mark Sub1 = ");
		int m1=s.nextInt();

		System.out.println("Enter Mark Sub2 = ");
		int m2=s.nextInt();

		System.out.println("Enter Mark Sub3 = ");
		int m3=s.nextInt();

	  	Date d=new Date(day,month,year);
        Student  s1 = new Student(id,name,m1,m2,m3);
        s1.display();
    }
}
