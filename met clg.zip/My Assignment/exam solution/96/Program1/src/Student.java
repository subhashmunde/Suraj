package cal;

public class Student
{
	private int id;
	private String name;
	//Date d1; 
	int[] marks= new int[3];
	 
     //public Student(int id, String name,Date d,int s1, int s2, int s3)
     public Student(int id, String name,int s1, int s2, int s3)
     {
          this.id = id;
          this.name = name;
          marks[0] = s1;
          marks[1] = s2;
          marks[2] = s3;
          //d1 = new Date(d.day, d.month, d.year);
     }
     
     public void display()
     {			
	  System.out.println("Student Id = "+id);
	  System.out.println("Student Name = "+name);
	 // System.out.println("Student DOB = "+d1.day+"/ "+d1.month+"/ "+d1.year);
	  System.out.println("Mark Sub1 = "+marks[0]);
	  System.out.println("Mark Sub2 = "+marks[1]);
	  System.out.println("Mark Sub3 = "+marks[2]);
     }


}
