package cal;
class Date
{ 
	//private:
	int day;
	int month;
	int year;

	Date(int day, int month, int year)
	{
        day=day;
	    month=month;
	    year=year;
	}
	
	/*
	public void display()
	{
	  System.out.println("Day= "+day);
	  System.out.println("Month= "+month);
	  System.out.println("Year= "+year);
	}
	*/

}
