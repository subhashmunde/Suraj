package college;

public abstract class Staff
{
	protected String name;
	protected String address;
	
	public Staff(String nm, String adr)
	{
		name=nm;
		address=adr;	
	}

	public void setName(String nm)
	{
	   name= nm;
	} 

	public String getName()
	{
	  return name;
	}

	public void setAddress(String adr)
	{
	   address= adr;
	} 

	public String getAddress()
	{
	  return address;
	}

	public abstract double getSalary();
}
