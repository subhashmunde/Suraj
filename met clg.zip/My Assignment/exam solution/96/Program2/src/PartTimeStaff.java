
package college;

class PartTimeStaff extends Staff
{
	private String Dept;
	private int hours;
	private int rate;

	public PartTimeStaff(String nm,string adr)
	{
	   super(nm, adr);
	} 
	
	public void getHours()
	{
	   return hours;
	}

	public int setHours(int hr,int rt)
	{
	   hours=hr;
	   rate=rt;
	}

	public double getSalary()
	{
	  double salary;
	  salary=hours*rate;
	  return salary;
	}

}
