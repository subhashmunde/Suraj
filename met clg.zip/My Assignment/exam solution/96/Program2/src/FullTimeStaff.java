package college;

class FullTimeStaff extends Staff
{
	private String Dept;

	public FullTimeStaff(String nm,string adr,String dp)
	{
		super(nm, adr);
		Dept=dp;
	} 

	public double getSalary()
	{
	  
	}

}
