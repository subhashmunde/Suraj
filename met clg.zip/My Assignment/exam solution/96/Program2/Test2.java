import college.*;
import java.util.Scanner;
class Test2
{
	public Static void main(String[] args)
	{
		
		Scanner s=new Scanner(System.in);

		System.out.println("Enter Name=");
		String name= s.nextLine();  
		System.out.println("Enter Address=");
		String address= s.nextLine();  
 
		Staff f=new FullTimeStaff(name,address);
		Loan p=new PartTimeStaff(name,address);
	}




}
