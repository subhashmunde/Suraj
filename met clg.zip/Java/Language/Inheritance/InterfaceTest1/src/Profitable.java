package edu.met.banking;

public interface Profitable {

	double interest(int months);

	float MIN_RATE = 4.0f;
}

