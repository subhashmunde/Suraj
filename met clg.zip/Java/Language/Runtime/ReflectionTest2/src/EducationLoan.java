package finance;

public class EducationLoan {

	@MaxDuration 
	public float common(double amount, int period) {
		return 6;
	}

	public float masters(double amount, int period) {
		return 6.5f;
	}
}

