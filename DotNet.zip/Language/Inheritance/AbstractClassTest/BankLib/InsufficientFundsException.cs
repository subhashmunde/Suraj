namespace Met.Banking;

//only a type defined with public modifier is visible
//outside of the current assembly (project)
public class InsufficientFundsException : ApplicationException {}
